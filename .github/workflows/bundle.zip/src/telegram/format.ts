import type { HistoryStats } from "../history";
import type { ScoreResult } from "../scoring";
import type { Observation } from "../types";
import { isAllowedBuyUrl } from "../security";

export function escapeHtml(s: string): string {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

export function inr(n: number): string {
  return "₹" + new Intl.NumberFormat("en-IN", { maximumFractionDigits: 2 }).format(n);
}

const LEVEL_HEADER: Record<string, string> = {
  ULTRA: "🚨🔥 ULTRA DEAL DETECTED",
  "VERY HIGH": "🚨 VERY HIGH DEAL",
  HIGH: "🔥 HIGH DEAL",
  GOOD: "✅ GOOD DEAL",
  NORMAL: "ℹ️ Price note",
};

export function historyLine(stats: HistoryStats, score: ScoreResult): string {
  if (!stats.hasHistory) return "NO HISTORY (low confidence)";
  const days = Math.max(1, Math.round(stats.spanDays));
  const ref = score.referencePrice ? ` · normal ≈ ${inr(Math.round(score.referencePrice))}` : "";
  return `${days}-day data available${ref}`;
}

export function buildCaption(
  obs: Observation,
  score: ScoreResult,
  stats: HistoryStats,
  detectedAt: Date,
  timeZone = "Asia/Kolkata",
): string {
  const time = new Intl.DateTimeFormat("en-IN", { hour: "numeric", minute: "2-digit", hour12: true, timeZone }).format(detectedAt);
  const platform = obs.platform === "amazon" ? "Amazon" : "Flipkart";
  const lines: string[] = [];
  if (obs.isMock) lines.push("🧪 <b>MOCK / TEST DATA — not a real deal</b>");
  lines.push(`<b>${LEVEL_HEADER[score.level]}</b>`, "");
  lines.push(`📦 ${escapeHtml(obs.title.slice(0, 120))}`);
  lines.push(`🛒 Platform: ${platform}`, "");
  lines.push(`💰 Current Price: <b>${inr(obs.price)}</b>`);
  if (stats.previousPrice !== null) lines.push(`📉 Previous Price: ${inr(stats.previousPrice)}`);
  if (obs.mrp) lines.push(`🏷️ MRP: ${inr(obs.mrp)}`);
  if (score.claimedDiscountPercent !== null) {
    const note = score.flags.includes("FAKE_MRP") ? " (MRP looks inflated)" : "";
    lines.push(`📊 Discount: ${Math.round(score.claimedDiscountPercent)}%${note}`);
  }
  lines.push("", `🎯 Deal Score: <b>${score.total}/100</b>`, `⚡ Level: <b>${score.level}</b>`);
  lines.push(`📦 Availability: ${obs.available ? "In Stock" : "Out of Stock"}`);
  lines.push(`🕒 Detected: ${time}`);
  lines.push(`📈 History: ${historyLine(stats, score)}`);
  if (score.flags.includes("AI_UNAVAILABLE")) lines.push("🤖 AI verification unavailable");
  const text = lines.join("\n");
  return text.length <= 1024 ? text : text.slice(0, 1020) + "…"; // Telegram caption limit
}

/** Inline BUY button. Returns null when the URL fails the domain allowlist. */
export function buildKeyboard(obs: Observation): { inline_keyboard: Array<Array<{ text: string; url: string }>> } | null {
  if (!isAllowedBuyUrl(obs.url)) return null;
  const name = obs.platform === "amazon" ? "AMAZON" : "FLIPKART";
  return { inline_keyboard: [[{ text: `🛒 BUY NOW ON ${name}`, url: obs.url }]] };
}
