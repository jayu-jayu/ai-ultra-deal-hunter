import type { PricePoint } from "./types";

export interface HistoryStats {
  count: number;
  spanDays: number;
  previousPrice: number | null;
  min7: number | null;
  median7: number | null;
  min30: number | null;
  median30: number | null;
  min90: number | null;
  max90: number | null;
  maxMrp90: number | null;
  /** Fraction (0..1) of past observations at or below the current price. */
  percentile: number | null;
  hasHistory: boolean;
}

const DAY = 86_400_000;

export function median(values: number[]): number | null {
  if (values.length === 0) return null;
  const s = [...values].sort((a, b) => a - b);
  const mid = Math.floor(s.length / 2);
  return s.length % 2 ? s[mid] : (s[mid - 1] + s[mid]) / 2;
}

/** Minimum number of past observations before history is trusted. */
export const MIN_HISTORY_POINTS = 5;

/**
 * Stats over PAST observations only (do not include the current sighting).
 */
export function computeStats(past: PricePoint[], currentPrice: number, now: Date): HistoryStats {
  const t = now.getTime();
  const valid = past
    .map((p) => ({ ...p, ts: Date.parse(p.at) }))
    .filter((p) => Number.isFinite(p.ts) && p.ts <= t && p.price >= 0)
    .sort((a, b) => a.ts - b.ts);

  const within = (days: number) => valid.filter((p) => t - p.ts <= days * DAY);
  const w7 = within(7).map((p) => p.price);
  const w30 = within(30).map((p) => p.price);
  const w90 = within(90);
  const prices90 = w90.map((p) => p.price);
  const mrps90 = w90.map((p) => p.mrp).filter((m): m is number => m !== null);

  const last = valid.length ? valid[valid.length - 1] : null;
  const spanDays = valid.length ? (t - valid[0].ts) / DAY : 0;

  return {
    count: valid.length,
    spanDays,
    previousPrice: last ? last.price : null,
    min7: w7.length ? Math.min(...w7) : null,
    median7: median(w7),
    min30: w30.length ? Math.min(...w30) : null,
    median30: median(w30),
    min90: prices90.length ? Math.min(...prices90) : null,
    max90: prices90.length ? Math.max(...prices90) : null,
    maxMrp90: mrps90.length ? Math.max(...mrps90) : null,
    percentile: valid.length ? valid.filter((p) => p.price <= currentPrice).length / valid.length : null,
    hasHistory: valid.length >= MIN_HISTORY_POINTS,
  };
}
