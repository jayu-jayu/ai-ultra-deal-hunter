export interface Settings {
  minScore: number;
  minDiscountPercent: number;
  maxAlertPrice: number;
  cooldownHours: number;
  dropFractionForRealert: number;
  alertsEnabled: boolean;
  aiEnabled: boolean;
  amazonEnabled: boolean;
  flipkartEnabled: boolean;
}

export const DEFAULT_SETTINGS: Settings = {
  minScore: 60,
  minDiscountPercent: 30,
  maxAlertPrice: 499,
  cooldownHours: 6,
  dropFractionForRealert: 0.15,
  alertsEnabled: true,
  aiEnabled: false,
  amazonEnabled: true,
  flipkartEnabled: true,
};

/** Merge stored string settings over defaults, ignoring junk values. */
export function mergeSettings(stored: Record<string, string>): Settings {
  const s: Settings = { ...DEFAULT_SETTINGS };
  const num = (k: string, min: number, max: number): number | undefined => {
    const v = Number(stored[k]);
    return stored[k] !== undefined && Number.isFinite(v) && v >= min && v <= max ? v : undefined;
  };
  const bool = (k: string): boolean | undefined =>
    stored[k] === "true" ? true : stored[k] === "false" ? false : undefined;

  s.minScore = num("minScore", 0, 100) ?? s.minScore;
  s.minDiscountPercent = num("minDiscountPercent", 0, 100) ?? s.minDiscountPercent;
  s.maxAlertPrice = num("maxAlertPrice", 1, 1_000_000) ?? s.maxAlertPrice;
  s.cooldownHours = num("cooldownHours", 0, 168) ?? s.cooldownHours;
  s.dropFractionForRealert = num("dropFractionForRealert", 0.01, 0.9) ?? s.dropFractionForRealert;
  s.alertsEnabled = bool("alertsEnabled") ?? s.alertsEnabled;
  s.aiEnabled = bool("aiEnabled") ?? s.aiEnabled;
  s.amazonEnabled = bool("amazonEnabled") ?? s.amazonEnabled;
  s.flipkartEnabled = bool("flipkartEnabled") ?? s.flipkartEnabled;
  return s;
}
