import type { Env, Observation, Platform } from "../types";

export class NotConfiguredError extends Error {
  constructor(name: string) {
    super(`${name} connector is not configured (missing credentials)`);
    this.name = "NotConfiguredError";
  }
}

/** Every platform implements this. Add a new platform = add one file. */
export interface Connector {
  readonly name: string;
  readonly platform: Platform;
  isConfigured(env: Env): boolean;
  fetchObservations(env: Env, now: Date): Promise<Observation[]>;
}
