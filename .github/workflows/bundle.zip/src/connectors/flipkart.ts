import type { Env, Observation, Platform } from "../types";
import { NotConfiguredError, type Connector } from "./base";

/**
 * Phase 5 placeholder. Real implementation will use the official Flipkart
 * Affiliate API (headers Fk-Affiliate-Id / Fk-Affiliate-Token). No scraping.
 */
export class FlipkartConnector implements Connector {
  readonly name = "flipkart";
  readonly platform: Platform = "flipkart";
  isConfigured(env: Env): boolean {
    return Boolean(env.FLIPKART_AFFILIATE_ID && env.FLIPKART_AFFILIATE_TOKEN);
  }
  async fetchObservations(env: Env, _now: Date): Promise<Observation[]> {
    if (!this.isConfigured(env)) throw new NotConfiguredError(this.name);
    throw new Error("Flipkart connector not implemented yet (Phase 5)");
  }
}
