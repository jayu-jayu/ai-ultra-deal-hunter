import type { Env, Observation, Platform } from "../types";
import { NotConfiguredError, type Connector } from "./base";

/**
 * Phase 6 placeholder. Real implementation will use the official Amazon
 * Creators API, which requires an eligible Associates account. No scraping.
 */
export class AmazonConnector implements Connector {
  readonly name = "amazon";
  readonly platform: Platform = "amazon";
  isConfigured(env: Env): boolean {
    return Boolean(env.AMAZON_CREDENTIAL_ID && env.AMAZON_CREDENTIAL_SECRET);
  }
  async fetchObservations(env: Env, _now: Date): Promise<Observation[]> {
    if (!this.isConfigured(env)) throw new NotConfiguredError(this.name);
    throw new Error("Amazon connector not implemented yet (Phase 6)");
  }
}
