import type { Env, Observation, Platform } from "../types";
import type { Connector } from "./base";

interface MockProduct {
  id: string;
  platform: Platform;
  title: string;
  mrp: number;
  /** Price over successive scans (loops). The last "normal" price is the deal. */
  sequence: number[];
  seller: string;
}

const IMG = (label: string) =>
  `https://placehold.co/600x600/0b1220/38bdf8/png?text=${encodeURIComponent(label)}`;

export const MOCK_PRODUCTS: MockProduct[] = [
  { id: "MOCK-A1", platform: "amazon", title: "[MOCK] Wireless Earbuds", mrp: 999, sequence: [499, 479, 449, 429, 429, 99], seller: "MockSeller" },
  { id: "MOCK-A2", platform: "amazon", title: "[MOCK] USB-C Fast Charger", mrp: 799, sequence: [349, 349, 329, 329, 349, 49], seller: "MockSeller" },
  { id: "MOCK-F1", platform: "flipkart", title: "[MOCK] Mechanical Keyboard", mrp: 1499, sequence: [899, 899, 849, 849, 879, 199], seller: "MockRetail" },
  { id: "MOCK-F2", platform: "flipkart", title: "[MOCK] Wireless Mouse", mrp: 499, sequence: [299, 279, 279, 289, 289, 99], seller: "MockRetail" },
  // Fake-MRP trap: always ~₹49 with a huge MRP; must NOT score as a great deal once history exists.
  { id: "MOCK-F3", platform: "flipkart", title: "[MOCK] Phone Screen Cleaner", mrp: 999, sequence: [49, 49, 49, 49, 49, 49], seller: "MockRetail" },
  { id: "MOCK-A3", platform: "amazon", title: "[MOCK] Bluetooth Speaker", mrp: 2999, sequence: [1499, 1499, 1399, 1399, 1499, 499], seller: "MockSeller" },
];

/** Which step of each product's price sequence applies at this time (changes every `stepMinutes`). */
export function mockStep(now: Date, stepMinutes = 5): number {
  return Math.floor(now.getTime() / (stepMinutes * 60_000));
}

export class MockConnector implements Connector {
  readonly name = "mock";
  // Mock products are labelled by platform so they exercise both code paths,
  // but every observation carries isMock = true.
  readonly platform: Platform = "amazon";

  isConfigured(): boolean {
    return true;
  }

  async fetchObservations(_env: Env, now: Date): Promise<Observation[]> {
    const step = mockStep(now);
    return MOCK_PRODUCTS.map((p) => {
      const price = p.sequence[step % p.sequence.length];
      return {
        platform: p.platform,
        externalId: p.id,
        title: p.title,
        url:
          p.platform === "amazon"
            ? `https://www.amazon.in/dp/${p.id}`
            : `https://www.flipkart.com/p/${p.id}`,
        imageUrl: IMG(p.title.replace("[MOCK] ", "")),
        price,
        mrp: p.mrp,
        available: true,
        seller: p.seller,
        category: "mock",
        observedAt: now.toISOString(),
        isMock: true,
      };
    });
  }
}
