import { MockConnector } from "./connectors/mock";
import type { Env } from "./types";

const json = (data: unknown, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json", "x-content-type-options": "nosniff", "cache-control": "no-store" },
  });

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);
    if (url.pathname === "/health") {
      let db = "unknown";
      try {
        await env.DB.prepare("SELECT 1").first();
        db = "ok";
      } catch {
        db = "error";
      }
      return json({ ok: db === "ok", service: "ultra-deal-hunter", phase: 1, db, mockMode: env.MOCK_MODE === "true", time: new Date().toISOString() });
    }
    return json({ error: "not found" }, 404);
  },

  // Phase 1 skeleton: proves the cron trigger fires. Real scanner arrives in Phase 2.
  async scheduled(_event: ScheduledController, env: Env): Promise<void> {
    console.log("SCAN_START", JSON.stringify({ mock: env.MOCK_MODE === "true" }));
    const items = await new MockConnector().fetchObservations(env, new Date());
    console.log("SOURCE_FETCH", JSON.stringify({ source: "mock", count: items.length }));
    console.log("SCAN_COMPLETE");
  },
};
