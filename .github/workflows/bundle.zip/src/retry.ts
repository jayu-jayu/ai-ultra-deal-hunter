export interface RetryOptions {
  retries: number; // additional attempts after the first (bounded, never infinite)
  baseMs: number;
  maxMs: number;
  sleep?: (ms: number) => Promise<void>;
  random?: () => number;
  /** Return false to stop retrying (e.g. 4xx errors). */
  shouldRetry?: (err: unknown) => boolean;
}

export async function withRetry<T>(fn: (attempt: number) => Promise<T>, o: RetryOptions): Promise<T> {
  const sleep = o.sleep ?? ((ms: number) => new Promise<void>((r) => setTimeout(r, ms)));
  const rand = o.random ?? Math.random;
  const attempts = Math.max(0, Math.min(o.retries, 10));
  let lastErr: unknown;
  for (let i = 0; i <= attempts; i++) {
    try {
      return await fn(i);
    } catch (err) {
      lastErr = err;
      if (i === attempts || (o.shouldRetry && !o.shouldRetry(err))) break;
      const cap = Math.min(o.maxMs, o.baseMs * 2 ** i);
      await sleep(Math.round(cap / 2 + rand() * (cap / 2))); // jitter
    }
  }
  throw lastErr;
}
