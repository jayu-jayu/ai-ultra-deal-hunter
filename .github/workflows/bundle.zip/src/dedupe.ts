import type { Level } from "./types";
import { levelRank } from "./scoring";

export interface LastAlert {
  price: number;
  level: Level;
  available: boolean;
  sentAt: string; // ISO
}

export interface Candidate {
  price: number;
  level: Level;
  available: boolean;
}

export interface DedupeConfig {
  cooldownHours: number;
  dropFractionForRealert: number; // e.g. 0.15 = 15% below last alerted price
}

export type DedupeReason =
  | "NEW"
  | "PRICE_DROP"
  | "TIER_UP"
  | "RESTOCK"
  | "DUPLICATE"
  | "COOLDOWN";

export interface DedupeDecision {
  send: boolean;
  reason: DedupeReason;
}

export function decideAlert(
  last: LastAlert | null,
  cur: Candidate,
  now: Date,
  cfg: DedupeConfig,
): DedupeDecision {
  if (!last) return { send: true, reason: "NEW" };

  if (!last.available && cur.available) return { send: true, reason: "RESTOCK" };
  if (levelRank(cur.level) > levelRank(last.level)) return { send: true, reason: "TIER_UP" };
  if (cur.price <= last.price * (1 - cfg.dropFractionForRealert)) {
    return { send: true, reason: "PRICE_DROP" };
  }

  const ageMs = now.getTime() - Date.parse(last.sentAt);
  const inCooldown = Number.isFinite(ageMs) && ageMs < cfg.cooldownHours * 3_600_000;
  return { send: false, reason: inCooldown ? "COOLDOWN" : "DUPLICATE" };
}
