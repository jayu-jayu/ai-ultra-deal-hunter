export type Platform = "amazon" | "flipkart";
export type Level = "ULTRA" | "VERY HIGH" | "HIGH" | "GOOD" | "NORMAL";

/** One normalized product sighting from any connector. */
export interface Observation {
  platform: Platform;
  externalId: string;
  title: string;
  url: string;
  imageUrl: string | null;
  price: number;
  mrp: number | null;
  available: boolean;
  seller: string | null;
  category: string | null;
  observedAt: string; // ISO
  isMock: boolean;
}

export interface PricePoint {
  price: number;
  mrp: number | null;
  at: string; // ISO
}

export interface Env {
  DB: D1Database;
  MOCK_MODE?: string;
  TELEGRAM_BOT_TOKEN?: string;
  TELEGRAM_CHAT_ID?: string;
  TELEGRAM_WEBHOOK_SECRET?: string;
  DASHBOARD_PASSWORD?: string;
  FLIPKART_AFFILIATE_ID?: string;
  FLIPKART_AFFILIATE_TOKEN?: string;
  AMAZON_CREDENTIAL_ID?: string;
  AMAZON_CREDENTIAL_SECRET?: string;
  GEMINI_API_KEY?: string;
}
