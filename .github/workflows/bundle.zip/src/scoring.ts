import type { HistoryStats } from "./history";
import type { Level, Observation } from "./types";

export interface ScoreResult {
  total: number; // 0..100
  level: Level;
  components: { history: number; tier: number; credibility: number; availability: number; ai: number | null };
  flags: string[]; // NO_HISTORY, FAKE_MRP, NOT_A_DEAL, AI_UNAVAILABLE, UNAVAILABLE
  dropPercent: number | null; // vs reference price
  referencePrice: number | null;
  claimedDiscountPercent: number | null;
}

export const NO_HISTORY_CAP = 70;

export function tierLevel(price: number): Level {
  if (price <= 49) return "ULTRA";
  if (price <= 99) return "VERY HIGH";
  if (price <= 199) return "HIGH";
  if (price <= 499) return "GOOD";
  return "NORMAL";
}

const LEVEL_RANK: Record<Level, number> = { NORMAL: 0, GOOD: 1, HIGH: 2, "VERY HIGH": 3, ULTRA: 4 };
export const levelRank = (l: Level): number => LEVEL_RANK[l];

const clamp01 = (n: number) => Math.max(0, Math.min(1, n));

function tierPoints(price: number): number {
  if (price <= 49) return 20;
  if (price <= 99) return 16;
  if (price <= 199) return 12;
  if (price <= 499) return 7;
  return 0;
}

/**
 * Deterministic score. AI points (0..15) are optional; when absent the other
 * 85 points are rescaled to 100 and flagged AI_UNAVAILABLE.
 */
export function scoreDeal(obs: Observation, stats: HistoryStats, aiPoints: number | null = null): ScoreResult {
  const flags: string[] = [];
  const claimed =
    obs.mrp && obs.mrp > obs.price ? ((obs.mrp - obs.price) / obs.mrp) * 100 : null;

  // Reference = what the product normally sells for.
  const reference = stats.hasHistory ? (stats.median30 ?? stats.median7 ?? stats.previousPrice) : null;
  let dropPercent: number | null = null;
  let history = 0;

  if (stats.hasHistory && reference && reference > 0) {
    dropPercent = Math.max(0, ((reference - obs.price) / reference) * 100);
    history = obs.price >= reference * 0.95 ? 0 : 40 * clamp01(dropPercent / 90);
  } else {
    flags.push("NO_HISTORY");
    // Reduced confidence: at most half the history points, from the claimed discount.
    history = claimed ? 20 * clamp01(claimed / 90) : 0;
  }

  // Credibility: is the listed MRP believable?
  let credibility: number;
  if (obs.mrp === null || obs.mrp <= obs.price) {
    credibility = 5;
  } else if (stats.hasHistory && stats.max90 !== null) {
    // The highest price actually seen in 90 days is what the product "really" sells at.
    const seen = stats.max90;
    if (obs.mrp > seen * 2) {
      credibility = 2;
      flags.push("FAKE_MRP");
    } else if (obs.mrp <= seen * 1.25) {
      credibility = 15;
    } else {
      credibility = 9;
    }
  } else {
    credibility = 6; // MRP unverifiable without history
  }

  const availability = obs.available ? (obs.seller ? 10 : 8) : 0;
  if (!obs.available) flags.push("UNAVAILABLE");

  const base = history + tierPoints(obs.price) + credibility + availability;
  let total: number;
  let ai: number | null = null;
  if (aiPoints === null) {
    flags.push("AI_UNAVAILABLE");
    total = (base / 85) * 100;
  } else {
    ai = Math.max(0, Math.min(15, aiPoints));
    total = base + ai;
  }
  if (flags.includes("NO_HISTORY")) total = Math.min(total, NO_HISTORY_CAP);
  total = Math.round(Math.max(0, Math.min(100, total)));

  // Level comes from the absolute tier, but is withdrawn when the price is
  // known to be normal or the MRP is fake.
  let level = tierLevel(obs.price);
  const notADeal = stats.hasHistory && dropPercent !== null && dropPercent < 10;
  if (notADeal) flags.push("NOT_A_DEAL");
  if (notADeal) level = "NORMAL";
  if (!obs.available) level = "NORMAL";

  return {
    total,
    level,
    components: { history: Math.round(history), tier: tierPoints(obs.price), credibility, availability, ai },
    flags,
    dropPercent,
    referencePrice: reference,
    claimedDiscountPercent: claimed,
  };
}
