const ALLOWED_BUY_DOMAINS = [
  "amazon.in",
  "amazon.com",
  "amzn.in",
  "amzn.to",
  "flipkart.com",
  "dl.flipkart.com",
];

/** True only for https URLs on Amazon/Flipkart domains (no look-alikes, no credentials in URL). */
export function isAllowedBuyUrl(raw: string): boolean {
  let u: URL;
  try {
    u = new URL(raw);
  } catch {
    return false;
  }
  if (u.protocol !== "https:") return false;
  if (u.username || u.password) return false;
  const host = u.hostname.toLowerCase();
  return ALLOWED_BUY_DOMAINS.some((d) => host === d || host.endsWith("." + d));
}

/** Image URLs must be https; host is not restricted (retailer CDNs vary). */
export function isSafeImageUrl(raw: string | null): boolean {
  if (!raw) return false;
  try {
    const u = new URL(raw);
    return u.protocol === "https:" && !u.username && !u.password;
  } catch {
    return false;
  }
}

/** Constant-time string compare for secrets. */
export function safeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

/** Only the configured chat may run admin commands. Fails closed if unset. */
export function isAuthorizedChat(chatId: number | string | undefined, configured: string | undefined): boolean {
  if (chatId === undefined || !configured) return false;
  return String(chatId) === String(configured).trim();
}

export function redact(text: string, secrets: Array<string | undefined>): string {
  let out = text;
  for (const s of secrets) if (s && s.length >= 6) out = out.split(s).join("[REDACTED]");
  return out;
}
