-- AI Ultra Deal Hunter: initial schema (Cloudflare D1 / SQLite)
CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  platform TEXT NOT NULL CHECK (platform IN ('amazon','flipkart')),
  external_product_id TEXT NOT NULL,
  title TEXT NOT NULL,
  url TEXT NOT NULL,
  image_url TEXT,
  category TEXT,
  seller TEXT,
  is_mock INTEGER NOT NULL DEFAULT 0,
  first_seen TEXT NOT NULL,
  last_seen TEXT NOT NULL,
  UNIQUE (platform, external_product_id)
);

CREATE TABLE IF NOT EXISTS price_observations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  current_price REAL NOT NULL CHECK (current_price >= 0),
  mrp REAL,
  discount_percent REAL,
  availability INTEGER NOT NULL DEFAULT 1,
  observed_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_obs_product_time ON price_observations (product_id, observed_at DESC);

CREATE TABLE IF NOT EXISTS deals (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  current_price REAL NOT NULL,
  historical_price REAL,
  drop_percent REAL,
  deal_score INTEGER NOT NULL,
  ai_score INTEGER,
  level TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'detected',
  flags TEXT,
  detected_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_deals_time ON deals (detected_at DESC);
CREATE INDEX IF NOT EXISTS idx_deals_product ON deals (product_id, detected_at DESC);

CREATE TABLE IF NOT EXISTS alerts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  deal_id INTEGER NOT NULL REFERENCES deals(id) ON DELETE CASCADE,
  product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  alerted_price REAL NOT NULL,
  alerted_level TEXT NOT NULL,
  alerted_available INTEGER NOT NULL DEFAULT 1,
  reason TEXT,
  telegram_message_id INTEGER,
  sent_at TEXT,
  delivery_status TEXT NOT NULL DEFAULT 'queued' CHECK (delivery_status IN ('queued','sent','failed')),
  retry_count INTEGER NOT NULL DEFAULT 0,
  next_retry_at TEXT,
  error_message TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_alerts_product ON alerts (product_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_alerts_queue ON alerts (delivery_status, next_retry_at);

CREATE TABLE IF NOT EXISTS system_state (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
