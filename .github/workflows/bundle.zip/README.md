# AI Ultra Deal Hunter

Personal deal-alert system: monitors **authorized** Amazon/Flipkart data, tracks price history, scores deals, alerts your Telegram. **Never buys anything. No scraping, no CAPTCHA/anti-bot bypass.** Final purchase is always manual.

Status: **Phase 0-3 core done and tested** (history, scoring, dedupe, security, Telegram formatting, mock connector, schema). Phases 4+ (D1 store, scanner, Telegram send/commands, real connectors, AI, dashboard) are next. See `docs/ARCHITECTURE.md`.

## Secrets (Cloudflare only, never GitHub)
See `.env.example`. Set in Cloudflare: Worker -> Settings -> Variables and Secrets.

## Deploy from an Android phone (Phase 1)
1. Cloudflare dashboard (browser) -> Storage & Databases -> D1 -> Create `ultra-deal-hunter`. Copy its ID.
2. In the D1 console, paste and run the contents of `migrations/0001_init.sql`.
3. On GitHub edit `wrangler.toml`: replace `PASTE_D1_DATABASE_ID_HERE`. Commit.
4. Cloudflare -> Workers & Pages -> Create -> import your GitHub repo (build command none; deploy command `npx wrangler deploy`).
5. Open `https://<your-worker>.workers.dev/health` -> expect `"ok": true`.
6. Worker -> Logs: after ~5 min you should see `SCAN_START` / `SCAN_COMPLETE`.

(Cloudflare's dashboard wording changes; if a label differs, tell me what you see.)

## Tests
GitHub runs them automatically (Actions tab -> Tests). No local setup needed.

## Reality checks
No guaranteed ₹1 deals, Amazon access, instant feeds, or permanent free hosting.
