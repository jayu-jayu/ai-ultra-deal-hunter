import { describe, expect, it } from "vitest";
import { computeStats } from "../src/history";
import { scoreDeal } from "../src/scoring";
import { decideAlert } from "../src/dedupe";
import { isAllowedBuyUrl, isAuthorizedChat, redact } from "../src/security";
import { withRetry } from "../src/retry";
import { buildCaption, buildKeyboard } from "../src/telegram/format";
import { MockConnector, MOCK_PRODUCTS } from "../src/connectors/mock";
import { mergeSettings } from "../src/config";
import type { Observation, PricePoint } from "../src/types";

const NOW = new Date("2026-10-07T12:00:00Z");
const daysAgo = (d: number) => new Date(NOW.getTime() - d * 86_400_000).toISOString();
const pts = (prices: number[], mrp: number | null = 999): PricePoint[] =>
  prices.map((p, i) => ({ price: p, mrp, at: daysAgo(prices.length - i) }));

const obs = (o: Partial<Observation> = {}): Observation => ({
  platform: "amazon", externalId: "X1", title: "Wireless Mouse", url: "https://www.amazon.in/dp/X1",
  imageUrl: "https://example.com/i.png", price: 49, mrp: 999, available: true, seller: "S",
  category: null, observedAt: NOW.toISOString(), isMock: false, ...o,
});

describe("price history", () => {
  it("computes medians/min and flags insufficient history", () => {
    const s = computeStats(pts([499, 479, 449, 429]), 49, NOW);
    expect(s.count).toBe(4);
    expect(s.hasHistory).toBe(false);
    expect(s.previousPrice).toBe(429);
    expect(s.min30).toBe(429);
    expect(s.median30).toBe(464);
    const s2 = computeStats(pts([499, 479, 449, 429, 439]), 49, NOW);
    expect(s2.hasHistory).toBe(true);
  });
  it("ignores future/invalid points", () => {
    const s = computeStats([{ price: 5, mrp: null, at: "garbage" }, { price: 5, mrp: null, at: "2030-01-01T00:00:00Z" }], 5, NOW);
    expect(s.count).toBe(0);
  });
});

describe("scoring", () => {
  it("₹499 → ₹49 scores strongly", () => {
    const stats = computeStats(pts([499, 489, 479, 469, 459, 449]), 49, NOW);
    const r = scoreDeal(obs({ price: 49 }), stats);
    expect(r.level).toBe("ULTRA");
    expect(r.total).toBeGreaterThanOrEqual(85);
    expect(r.flags).not.toContain("NO_HISTORY");
  });
  it("fake MRP: normally ₹49, MRP ₹999, current ₹49 is NOT a deal", () => {
    const stats = computeStats(pts([49, 49, 49, 49, 49, 49]), 49, NOW);
    const r = scoreDeal(obs({ price: 49, mrp: 999 }), stats);
    expect(r.flags).toContain("FAKE_MRP");
    expect(r.flags).toContain("NOT_A_DEAL");
    expect(r.level).toBe("NORMAL");
    expect(r.total).toBeLessThan(60);
  });
  it("no history is capped and labelled", () => {
    const stats = computeStats([], 49, NOW);
    const r = scoreDeal(obs({ price: 49 }), stats);
    expect(r.flags).toContain("NO_HISTORY");
    expect(r.total).toBeLessThanOrEqual(70);
  });
  it("unavailable product is never a deal", () => {
    const stats = computeStats(pts([499, 489, 479, 469, 459, 449]), 49, NOW);
    expect(scoreDeal(obs({ available: false }), stats).level).toBe("NORMAL");
  });
  it("AI points are used when supplied and not required", () => {
    const stats = computeStats(pts([499, 489, 479, 469, 459, 449]), 49, NOW);
    const withAi = scoreDeal(obs(), stats, 15);
    const noAi = scoreDeal(obs(), stats, null);
    expect(withAi.components.ai).toBe(15);
    expect(noAi.flags).toContain("AI_UNAVAILABLE");
    expect(noAi.total).toBeLessThanOrEqual(100);
  });
});

describe("duplicate protection", () => {
  const cfg = { cooldownHours: 6, dropFractionForRealert: 0.15 };
  const last = { price: 99, level: "VERY HIGH" as const, available: true, sentAt: daysAgo(0.05) };
  it("first sighting alerts", () => expect(decideAlert(null, { price: 99, level: "VERY HIGH", available: true }, NOW, cfg).send).toBe(true));
  it("same price does not alert again", () => {
    const d = decideAlert(last, { price: 99, level: "VERY HIGH", available: true }, NOW, cfg);
    expect(d.send).toBe(false);
    expect(d.reason).toBe("COOLDOWN");
  });
  it("₹299 → ₹99 is a new candidate", () => {
    const l = { price: 299, level: "GOOD" as const, available: true, sentAt: daysAgo(0.05) };
    expect(decideAlert(l, { price: 99, level: "VERY HIGH", available: true }, NOW, cfg).send).toBe(true);
  });
  it("restock alerts", () => {
    const l = { ...last, available: false };
    expect(decideAlert(l, { price: 99, level: "VERY HIGH", available: true }, NOW, cfg).reason).toBe("RESTOCK");
  });
  it("after cooldown same price is still a duplicate", () => {
    const old = { ...last, sentAt: daysAgo(2) };
    expect(decideAlert(old, { price: 99, level: "VERY HIGH", available: true }, NOW, cfg)).toEqual({ send: false, reason: "DUPLICATE" });
  });
});

describe("security", () => {
  it("allows only retailer domains", () => {
    expect(isAllowedBuyUrl("https://www.amazon.in/dp/B0")).toBe(true);
    expect(isAllowedBuyUrl("https://dl.flipkart.com/s/x")).toBe(true);
    expect(isAllowedBuyUrl("https://evilamazon.in/dp/B0")).toBe(false);
    expect(isAllowedBuyUrl("https://amazon.in.evil.com/")).toBe(false);
    expect(isAllowedBuyUrl("http://www.amazon.in/")).toBe(false);
    expect(isAllowedBuyUrl("https://user:pw@www.amazon.in/")).toBe(false);
    expect(isAllowedBuyUrl("javascript:alert(1)")).toBe(false);
  });
  it("unauthorized chats are rejected, fails closed when unset", () => {
    expect(isAuthorizedChat(123, "123")).toBe(true);
    expect(isAuthorizedChat(999, "123")).toBe(false);
    expect(isAuthorizedChat(123, undefined)).toBe(false);
  });
  it("redacts secrets", () => expect(redact("token=abc123456 fail", ["abc123456"])).toBe("token=[REDACTED] fail"));
});

describe("retry", () => {
  it("retries with backoff then succeeds", async () => {
    let n = 0; const waits: number[] = [];
    const r = await withRetry(async () => { if (++n < 3) throw new Error("x"); return "ok"; },
      { retries: 3, baseMs: 100, maxMs: 1000, sleep: async (m) => { waits.push(m); }, random: () => 0.5 });
    expect(r).toBe("ok"); expect(n).toBe(3); expect(waits.length).toBe(2);
  });
  it("is bounded (never infinite)", async () => {
    let n = 0;
    await expect(withRetry(async () => { n++; throw new Error("x"); }, { retries: 2, baseMs: 1, maxMs: 2, sleep: async () => {} })).rejects.toThrow();
    expect(n).toBe(3);
  });
  it("stops on non-retryable errors", async () => {
    let n = 0;
    await expect(withRetry(async () => { n++; throw new Error("400"); }, { retries: 5, baseMs: 1, maxMs: 2, sleep: async () => {}, shouldRetry: () => false })).rejects.toThrow();
    expect(n).toBe(1);
  });
});

describe("telegram formatting", () => {
  const stats = computeStats(pts([499, 489, 479, 469, 459, 449]), 49, NOW);
  it("caption has key fields, escapes HTML, labels mock", () => {
    const o = obs({ title: "<b>Hack</b> & Co", isMock: true });
    const c = buildCaption(o, scoreDeal(o, stats), stats, NOW);
    expect(c).toContain("MOCK / TEST DATA");
    expect(c).toContain("&lt;b&gt;Hack&lt;/b&gt; &amp; Co");
    expect(c).toContain("₹49");
    expect(c).toContain("Deal Score");
    expect(c.length).toBeLessThanOrEqual(1024);
  });
  it("BUY button only for allowed URLs", () => {
    expect(buildKeyboard(obs())?.inline_keyboard[0][0].url).toBe("https://www.amazon.in/dp/X1");
    expect(buildKeyboard(obs({ url: "https://evil.example/x" }))).toBeNull();
  });
});

describe("mock connector", () => {
  it("works without credentials and labels everything as mock", async () => {
    const items = await new MockConnector().fetchObservations({} as never, NOW);
    expect(items.length).toBe(MOCK_PRODUCTS.length);
    expect(items.every((i) => i.isMock && i.title.startsWith("[MOCK]"))).toBe(true);
  });
});

describe("settings", () => {
  it("ignores invalid stored values", () => {
    const s = mergeSettings({ minScore: "abc", cooldownHours: "12", alertsEnabled: "false" });
    expect(s.minScore).toBe(60);
    expect(s.cooldownHours).toBe(12);
    expect(s.alertsEnabled).toBe(false);
  });
});
