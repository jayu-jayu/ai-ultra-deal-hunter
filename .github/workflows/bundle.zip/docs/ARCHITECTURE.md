# Architecture decision (verified Oct 2026)

| Need | Choice | Why |
|---|---|---|
| Source of truth | GitHub | Edit/commit from phone browser |
| Scanner + cron | Cloudflare Workers Cron Trigger | Free plan includes cron triggers; no sleeping |
| Telegram webhook | Same Worker | Webhook = no always-on process needed |
| Dashboard + API | Same Worker (HTML served by Worker) | One deploy, one URL, no CORS |
| Database | Cloudflare D1 (SQLite) | Never pauses; same account as Worker |
| AI (optional) | Gemini free tier or Workers AI | Skipped cleanly when unavailable |

## Why NOT Vercel + Render
- Vercel Hobby cron: at most once per day, timing only within the hour. Unusable for scanning.
- Render free: web services sleep after 15 min; free Postgres expires after 30 days; no free background workers.
- Vercel adds nothing the Worker cannot already serve, so it is not used.

## Known limits / risks
- Workers free plan: ~10 ms CPU per invocation (waiting on network does not count, but parsing large feeds does). Mitigation: small paginated requests; if this fails in testing, move scanning to a public-repo GitHub Actions cron (5-min minimum, may be delayed).
- D1 free limits must be re-checked in your dashboard.
- Amazon real data requires an eligible Associates account with qualifying sales. The system runs on mock data without it.
- Affiliate feeds are not instant. ₹1 glitch deals may be missed. No guarantees.
